package com.example.kossan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KossanApplication {

	public static void main(String[] args) {
		SpringApplication.run(KossanApplication.class, args);
	}

}
